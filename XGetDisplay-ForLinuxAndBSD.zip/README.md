# XGetDisplay

XGetDisplay - Print Primary Monitor WidthxHeight+X+Y with X11

This application takes no additional arguments - easy to use!

Statically links all dependencies except -ldl for convenience

If you get build errors you will need to install dependencies
